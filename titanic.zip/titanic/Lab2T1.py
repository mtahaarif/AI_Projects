### Importing the Libraries
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import copy

### Reading Data from CSV file
train_data = pd.read_csv(r"E:\Documents\summers\Artificial Intelligence\Classification\titanic\train.csv")
test_data = pd.read_csv(r"E:\Documents\summers\Artificial Intelligence\Classification\titanic\test.csv")

# Select features and target
y = train_data['Survived'].values
X = train_data[['Pclass', 'Sex', 'Age', 'SibSp', 'Parch', 'Fare', 'Embarked']].copy()

# Encode categorical features
X['Sex'] = X['Sex'].map({'male': 0, 'female': 1})
X['Embarked'] = X['Embarked'].map({'S': 0, 'C': 1, 'Q': 2})

# Handle missing values
X['Age'].fillna(X['Age'].median(), inplace=True)
X['Embarked'].fillna(X['Embarked'].mode()[0], inplace=True)

# Convert to NumPy array
X = X.values

### Compute Model Output
def compute_model_output(x, w, b):
    z = np.dot(x, w) + b
    f_wb = 1 / (1 + np.exp(-z))  # sigmoid
    return f_wb

### Logistic Loss Function
def loss_function(f_wb, y):
    epsilon = 1e-15  # Avoid log(0)
    f_wb = np.clip(f_wb, epsilon, 1 - epsilon)
    return - (y * np.log(f_wb) + (1 - y) * np.log(1 - f_wb))

def logistic_loss_function(x, w, b, y):
    m = x.shape[0]
    total_loss = 0
    for i in range(m):
        f_wb_i = compute_model_output(x[i], w, b)
        total_loss += loss_function(f_wb_i, y[i])
    return total_loss / m

### Compute Gradient
def compute_gradient(x, y, w, b): 
    m, n = x.shape
    dj_dw = np.zeros_like(w)
    dj_db = 0.0

    for i in range(m):  
        f_wb_i = compute_model_output(x[i], w, b)
        error = f_wb_i - y[i]
        dj_dw += error * x[i]
        dj_db += error

    dj_dw /= m 
    dj_db /= m 
    return dj_dw, dj_db

### Gradient Descent
def gradient_descent(x, y, w_in, b_in, alpha, num_iters, cost_function, gradient_function): 
    w = np.array(w_in, dtype=float)  # Ensure w is NumPy array
    b = b_in
    J_history = []
    p_history = []

    for i in range(num_iters):
        dj_dw, dj_db = gradient_function(x, y, w, b)
        w -= alpha * dj_dw
        b -= alpha * dj_db
        J_history.append(cost_function(x, w, b, y))
        p_history.append((w.copy(), b))
        if i % (num_iters // 10) == 0 or i == num_iters - 1:
            print(f"Iteration {i:4}: Cost {J_history[-1]:.4f}, b: {b:.4f}")
            print("w:", np.round(w, 4))

    return w, b, J_history, p_history

### Initialize weights
initial_w = np.zeros(X.shape[1])
initial_b = 0
alpha = 0.3
num_iters = 1000

### Train the model
w, b, J, P = gradient_descent(X, y, initial_w, initial_b, alpha, num_iters, logistic_loss_function, compute_gradient)

### Final Prediction and Accuracy
f_wb = compute_model_output(X, w, b)
predictions = np.round(f_wb)
accuracy = np.mean(predictions == y)

print("\nFinal Parameters:")
print(f"w: {np.round(w, 4)}")
print(f"b: {b:.4f}")
print(f"\nTraining Accuracy: {accuracy * 100:.2f}%")
