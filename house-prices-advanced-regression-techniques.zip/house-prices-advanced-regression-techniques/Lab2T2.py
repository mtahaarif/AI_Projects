import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
import copy
import math

### Read CSV files
train_data = pd.read_csv(r"E:\Documents\summers\Artificial Intelligence\Linear_Regression\house-prices-advanced-regression-techniques\train.csv")
test_data = pd.read_csv(r"E:\Documents\summers\Artificial Intelligence\Linear_Regression\house-prices-advanced-regression-techniques\test.csv")

### Extract features and target
train_columns = train_data.columns.tolist()
train_columns.pop(0)  # Drop ID
Y_train = train_data[train_columns.pop(-1)]  # SalePrice
X_train = train_data[train_columns].copy()

### Encode categorical features
for i in range(len(train_columns)):
    X_train[train_columns[i]] = X_train[train_columns[i]].fillna(0)
    if not np.issubdtype(X_train[train_columns[i]].dtype, np.number):
        S1 = set(X_train[train_columns[i]])
        S1 = {x for x in S1 if not pd.isna(x)}
        S1 = {value: idx + 1 for idx, value in enumerate(S1)}
        X_train[train_columns[i]] = X_train[train_columns[i]].map(S1).fillna(0)

### Convert to numpy
X_train = X_train.values

### Hypothesis Function
def compute_model_output(x, w, b):
    return np.dot(x, w) + b

### Cost Function
def cost_function(X, w, b, y):
    m = X.shape[0]
    predictions = np.dot(X, w) + b  # shape: (m,)
    errors = predictions - y        # shape: (m,)
    cost = np.dot(errors, errors) / (2 * m)
    return cost

### Gradient Function
def compute_gradient(X, y, w, b):
    m = X.shape[0]
    predictions = np.dot(X, w) + b  # shape: (m,)
    errors = predictions - y        # shape: (m,)
    
    dj_dw = np.dot(X.T, errors) / m  # shape: (n,)
    dj_db = np.sum(errors) / m       # scalar
    
    return dj_dw, dj_db


### Gradient Descent
def gradient_descent(X, y, w_in, b_in, alpha, num_iters):
    w = w_in.copy()
    b = b_in
    J_history = []

    for i in range(num_iters):
        dj_dw, dj_db = compute_gradient(X, y, w, b)

        w -= alpha * dj_dw
        b -= alpha * dj_db

        cost = cost_function(X, w, b, y)
        J_history.append(cost)

        if i % (num_iters // 10) == 0 or i == num_iters - 1:
            print(f"Iteration {i:4}: Cost {cost:.4f}, b: {b:.4f}")
            print("w[0:5]:", w[:5])

    return w, b, J_history


### Initialize and Run
initial_w = np.zeros(X_train.shape[1])
initial_b = 0
alpha = 0.03
num_iters = 1000

w, b, J, P = gradient_descent(X_train, Y_train, initial_w, initial_b, alpha, num_iters)
