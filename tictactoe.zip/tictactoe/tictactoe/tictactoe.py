"""
Tic Tac Toe Player
"""
import math
import random

X = "X"
O = "O"
EMPTY = None
turn=0
Board = [[EMPTY, EMPTY, EMPTY],
            [EMPTY, EMPTY, EMPTY],
            [EMPTY, EMPTY, EMPTY]]

def initial_state():
    """
    Returns starting state of the board.
    """
    return Board


def player(board):
    global turn
    if turn%2 == 0 and turn !=1:
        return X
    else:        
        return O


def actions(board):
    options=[]
    for i in range(3):
        for j in range(3):
            if board[i][j] == EMPTY:
                options.append([i, j])
    return options


def result(board, action):
    action=list(action)
    board[action[0]][action[1]] = player(board)
    iterate()
    return board

def winner(board):
    I1=utility(board)
    if I1== 1:
        return X
    elif I1==-1:
        return O
    else:
        return None

def terminal(board):
    I1=utility(board)
    if I1== 1 or I1==-1:
        return True
    for i in board:
        for j in i:
            if j == EMPTY:
                return False
    return True

def utility(board):

    if (board[0][0] == board[1][1] == board[2][2]) or(board[0][2] == board[1][1] == board[2][0]):
        if board[1][1]==X:
            return 1
        elif board[1][1]==O:
            return -1
    if  (board[0][1] == board[1][1] == board[2][1]==X) or (board[0][0] == board[1][0] == board[2][0]==X)or (board[0][2] == board[1][2] == board[2][2]==X):
        return 1
    if  (board[0][1] == board[1][1] == board[2][1]==O) or (board[0][0] == board[1][0] == board[2][0]==O)or (board[0][2] == board[1][2] == board[2][2]==O):
        return -1
    if (board[0][0] == board[0][1] == board[0][2]==X)or (board[1][0] == board[1][1] == board[1][2]==X) or (board[2][0] == board[2][1] == board[2][2]==X): 
        return 1
    if (board[0][0] == board[0][1] == board[0][2]==O)or (board[1][0] == board[1][1] == board[1][2]==O) or (board[2][0] == board[2][1] == board[2][2]==O): 
        return -1
    else:
        return 0  


def minimax(board):
    if terminal(board):
        return None
    P1=player(board)
    if P1==X:
        P2=O
    elif P1==O:
        P2=X
    

    options= actions(board)
    B1=best_move(board,P1)
    B2=best_move(board,P2)
    if B1!=None:
        return B1
    elif B2!=None:
        return B2

    return options[random.randint(0, len(options)-1)]

def best_move(board,players):
    P1= players
    B1= board
    alert=False
    Count=0
    row_num=0
    #Check the best move horizontally
    for i in range(3):
        for j in range(3):
            if B1[i][j]==P1:
                Count+=1
        if Count ==2 :
            alert = True
            row_num= i
            break
        else:
            Count=0
        

    #return best move horizontally
    if alert==True:
        for j in range(3):
            if B1[row_num][j]== EMPTY :
                return (row_num,j )       

    alert=False
    Count=0
    #Check the best move vertically
    for i in range(3):
        for j in range(3):
            if B1[j][i]==P1:
                Count+=1
        if Count ==2 :
            alert = True
            row_num= i
            break
        else:
            Count=0
        

    #return best move vertically
    if alert==True:
        for j in range(3):
            if B1[j][row_num]== EMPTY :
                return (j,row_num)

    Count =0
    #Check the best move diagonally
    for i in range(3):
        if B1[i][i]==P1:
            Count+=1
    if Count ==2 :
        for i in range(3):
            if B1[i][i]== EMPTY:
                return (i,i)

    Count =0
    #Check the best move diagonally
    for i in range(3):
        if B1[i][2-i]==P1:
            Count+=1
    if Count ==2 :
        for i in range(3):
            if B1[i][2-i]== EMPTY:
                return (i,2-i)
 
    return None




def rst():
    global Board
    Board = [[EMPTY, EMPTY, EMPTY],
            [EMPTY, EMPTY, EMPTY],
            [EMPTY, EMPTY, EMPTY]]

def iterate():
    global turn
    turn+=1

